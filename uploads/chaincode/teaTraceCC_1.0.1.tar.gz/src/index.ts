export { TeaTraceContract, contracts } from "./teaTraceContract";

